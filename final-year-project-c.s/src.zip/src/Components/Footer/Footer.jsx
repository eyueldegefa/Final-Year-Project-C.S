import React from 'react'
import headerLogo from '.././../Images/headerLogo.png';
import './Footer.css'

function Footer() {
  return (
    <section className='row bg-dark text-white footer-container '>
        <div className='col-4'>
            <img src={headerLogo} alt="" />
            <div>links</div>
        </div>

        <div className='col-4'>
            <h3>Useful Links</h3>
            <p>Destinations</p>
            <p>Trains</p>
            <p>Sites</p>
        </div>

        <div className='col-4'>
            <h3>Contact info</h3>
            <p>support@ethiopianrailways.com</p>
            <p>+251986544345</p>
        </div>
    </section>
  )
}

export default Footer